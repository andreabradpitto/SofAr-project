var searchData=
[
  ['logger_2ecpp',['logger.cpp',['../logger_8cpp.html',1,'']]]
];
