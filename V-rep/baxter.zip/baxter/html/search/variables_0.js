var searchData=
[
  ['myfile',['myfile',['../logger_8cpp.html#a3a6bd5f7cd72e0a16f4a2054b9a2e64e',1,'logger.cpp']]]
];
